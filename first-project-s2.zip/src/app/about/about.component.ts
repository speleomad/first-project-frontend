import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  //template:`<p> about works from template</p>`,
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  info = {
    name: "Demo",
    email: "demo@gmail.com",
    tel: "12345678"
  }
  comments = [];
  newComment: boolean = false;
  comment={date:null,message:""}
  constructor() {
  }
  ngOnInit(): void {

  }

  addComment() {
    if(this.comment.message!=""){
      this.comment.date=new Date();
      this.comments.push({
        date:this.comment.date,
        message:this.comment.message
      });
      this.comment.message="";
    }
    // console.log("Add comment");
    /* this.comments.push({
      date: new Date,
      message: 'new message'
    }) */
    //this.newComment = true;
  }
}
